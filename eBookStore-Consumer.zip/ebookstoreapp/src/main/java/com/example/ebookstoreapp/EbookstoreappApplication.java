package com.example.ebookstoreapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.example.ebookstoreapp.repositories.BookStoreRepository;

import brave.sampler.Sampler;

@SpringBootApplication
@EnableDiscoveryClient
@EnableEurekaClient
public class EbookstoreappApplication implements CommandLineRunner {

	@Autowired
	@Qualifier(value = "bookStoreRepository")
	private BookStoreRepository bookStoreRepository;
	public static void main(String[] args) {
		SpringApplication.run(EbookstoreappApplication.class, args);
		System.out.println("\n\n\n e book store is working \n\n\n");
	}
	
	@Bean
	public Sampler alwSampler()
	{
		return Sampler.ALWAYS_SAMPLE;
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}
	

}
