package com.example.ebookstoreapp.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "book_details")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "book_title", nullable = false)
    private String bookTitle;

    @Column(name = "book_isbn", nullable = false, unique = true)
    private String bookIsbn;

    @Column(name = "book_number_of_pages")
    private int bookNumberOfPages;

    @Column(name = "book_year")
    private int bookYear;

    @Column(name = "author", nullable = false)
    private String author;

    @Column(name = "book_publisher")
    private String bookPublisher;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookIsbn() {
        return bookIsbn;
    }

    public void setBookIsbn(String bookIsbn) {
        this.bookIsbn = bookIsbn;
    }

    public int getBookNumberOfPages() {
        return bookNumberOfPages;
    }

    public void setBookNumberOfPages(int bookNumberOfPages) {
        this.bookNumberOfPages = bookNumberOfPages;
    }

    public int getBookYear() {
        return bookYear;
    }

    public void setBookYear(int bookYear) {
        this.bookYear = bookYear;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getBookPublisher() {
        return bookPublisher;
    }

    public void setBookPublisher(String bookPublisher) {
        this.bookPublisher = bookPublisher;
    }
}
