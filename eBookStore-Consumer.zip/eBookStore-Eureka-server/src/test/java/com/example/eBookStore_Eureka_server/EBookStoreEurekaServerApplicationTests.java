package com.example.eBookStore_Eureka_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
