package com.example.eBookStore_Consumer_Hystrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumerHystrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
