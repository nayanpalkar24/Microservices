package com.example.eBookStore_Consumer_Resilience4J.service;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
@Service
public class BookService {
 
    @Autowired
    private RestTemplate restTemplate;
 
    @Retry(name = "book_service")
    @CircuitBreaker(name = "book-service", fallbackMethod = "fallbackForGetBookById")
    public Object getBookById(Integer id) {
        try
        {
        	String url = "http://book-service/books/" + id;
            return restTemplate.getForObject(url, Object.class);
        }
        catch(Exception ex)
        {
        	ex.printStackTrace();
        	throw ex;
        }
    }
      
    // Fallback method if the book-service is down or unavailable
    public Object fallbackForGetBookById(Integer id, Exception ex) {
       System.out.println("Exception raised with message :===>" + ex.getMessage());
        return "Book information is currently unavailable. Please try again later.";
    }
}