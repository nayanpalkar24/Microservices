package com.example.eBookStore_Consumer_Feign_Resilience4J;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumerFeignResilience4JApplicationTests {

	@Test
	void contextLoads() {
	}

}
