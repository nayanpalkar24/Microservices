package com.example.eBookStore_Consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBookStoreConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumerApplication.class, args);
	}

}
