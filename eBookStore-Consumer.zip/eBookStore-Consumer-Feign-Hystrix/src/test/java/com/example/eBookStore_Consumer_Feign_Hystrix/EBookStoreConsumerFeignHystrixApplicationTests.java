package com.example.eBookStore_Consumer_Feign_Hystrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumerFeignHystrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
