package com.example.eBookStore_Consumer_Feign_Hystrix.Interface;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class BookService {
	
	 private BookServiceProxy bookServiceProxy;
	 
	 @Autowired
	 public BookService(BookServiceProxy bookServiceProxy)
	 {
		 this.bookServiceProxy = bookServiceProxy;
	 }
	 
	    public Object getBookById(Integer id) {
	        return  bookServiceProxy.getBookById(id);
	       
	    }
	    
	    public List<Object> getAllBooks() {
	        return  bookServiceProxy.getAllBooks();
	        
	    }

}
