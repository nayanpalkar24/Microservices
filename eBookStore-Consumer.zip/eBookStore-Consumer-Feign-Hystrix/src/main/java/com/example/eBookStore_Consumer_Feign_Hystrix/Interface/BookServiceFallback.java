package com.example.eBookStore_Consumer_Feign_Hystrix.Interface;


import java.util.Collections;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

@Component
public class BookServiceFallback implements BookServiceProxy {

	   @Override
	    public Object getBookById(Integer id) {
	        return  Collections.emptyList();
	       
	    }
	    
	   @Override
	    public List<Object> getAllBooks() {
	    	return  Collections.emptyList();
	        
	    }
      
   
    }

