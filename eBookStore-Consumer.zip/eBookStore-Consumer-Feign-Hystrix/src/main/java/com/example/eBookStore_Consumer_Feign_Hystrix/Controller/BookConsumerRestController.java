package com.example.eBookStore_Consumer_Feign_Hystrix.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.eBookStore_Consumer_Feign_Hystrix.Interface.BookServiceProxy;

@RestController
public class BookConsumerRestController {
 
    @Autowired
    private BookServiceProxy bookServiceProxy;
 
    @GetMapping("/get-books/{id}")
    public Object getBookById(@PathVariable("id") Integer id) {
        return  bookServiceProxy.getBookById(id);
       
    }
    
    @GetMapping("/get-books")
    public List<Object> getAllBooks() {
        return  bookServiceProxy.getAllBooks();
        
    }
}
