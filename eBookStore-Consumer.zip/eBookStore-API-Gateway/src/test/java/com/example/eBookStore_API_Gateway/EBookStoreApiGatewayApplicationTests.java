package com.example.eBookStore_API_Gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
